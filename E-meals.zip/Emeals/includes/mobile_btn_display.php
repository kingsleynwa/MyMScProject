<div class="btn-container">
    <button class='nav-btn'><i class="fas fa-list"></i></button>
    <button class='close-btn'><i class="fas fa-times"></i></button>
    <a href="cart.php" class='cart-btn'><i class="fas fa-shopping-cart">&nbsp;  <?php echo cart_num_display();?></i></a>
</div>