<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
<link rel="stylesheet" type="text/css" href="../assets/css/animate.css">
<link rel="stylesheet" type="text/css" href="../assets/css/fontawesome/css/all.css">
<link rel="stylesheet" type="text/css" href="../assets/css/fontawesome/css/all.min.css">
<link rel="stylesheet" type="text/css" href="../assets/css/fontawesome/css/brands.css">
<link rel="stylesheet" type="text/css" href="../assets/css/fontawesome/css/brands.min.css">
<link rel="stylesheet" type="text/css" href="../assets/css/fontawesome/css/fontawesome.css">
<link rel="stylesheet" type="text/css" href="assets/css/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="../assets/css/js/magnific-popup.css" type="text/css">
<link rel="stylesheet" href="../assets/css/js/slick-theme.css" type="text/css">
<link rel="stylesheet" href="../assets/css/js/slick.css" type="text/css">
<script type="text/javascript" src="../assets/js/jquery.js"></script>