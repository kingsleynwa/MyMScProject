<?php
include_once('includes/connection.php');
include_once('includes/functions.php');
session_start();

cancel_order();

delete_order();

?>